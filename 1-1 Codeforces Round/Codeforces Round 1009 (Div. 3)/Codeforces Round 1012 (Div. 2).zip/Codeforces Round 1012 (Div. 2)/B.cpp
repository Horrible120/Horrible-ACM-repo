#include <bits/extc++.h>
#define OOO cout<<">>>>";cout.flush();	//调试标识
#define H_test(x) println("---> {} <---",x);	//调试输出

using namespace std;
using namespace __gnu_pbds;

typedef long long ll;
typedef uint64_t ull;
using pll = pair<ll,ll>;
template <typename T> using v2ct = vector<vector<T>>;
template <typename T> using v3ct = vector<vector<vector<T>>>;

template <typename T, typename Compare = std::less<T>>
using oset = tree<T, null_type, Compare, rb_tree_tag, tree_order_statistics_node_update>;

const ll INF = 4e18, Mod = 1e9+7;
mt19937_64 rnd( (uintptr_t)(char*)(&INF)+time(0) );

ll tt=1;

void solve(){
	ll n,m;
	cin>>n>>m;
	v2ct<ll> mp(n+1,vector<ll>(m+1,0)),sumr(n+1,vector<ll>(m+1,0)),sumc(n+1,vector<ll>(m+1,0));
	for(ll i=1;i<=n;i++){
		string s;
		cin>>s;
		for(ll j=1;j<=m;j++)
			mp[i][j]=s[j-1]=='0'?0:1;
	}
		
	for(ll i=1;i<=n;i++)
		for(ll j=1;j<=m;j++){
			sumr[i][j]=sumr[i][j-1]+mp[i][j];
			sumc[i][j]=sumc[i-1][j]+mp[i][j];
		}
	for(ll i=1;i<=n;i++)
		for(ll j=1;j<=m;j++)
			if(mp[i][j]&&sumr[i][j]<j&&sumc[i][j]<i){
				cout<<"NO"<<endl;
				return;
			}
	cout<<"YES"<<endl;
}

int main() {
	ios::sync_with_stdio( 0 );
	cin.tie( 0 );
	cout.tie( 0 );
	
	cin >> tt;	//非多组测试数据时注释掉即可
	
	while ( tt-- ) {
		solve();
	}
	
	cout.flush();
	return 0;
}
